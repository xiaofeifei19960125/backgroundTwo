A Pen created at CodePen.io. You can find this one at https://codepen.io/jscottsmith/pen/yEMeaa.

 Interactive tubular dudes, aka wacky inflatable flailing arm guys